Scripts and input files for the section "Basic I/O Scripts" are in the "miscellaneous" folder.

Scripts for the section "An Object-Oriented Design" are in the "cameo" folder.