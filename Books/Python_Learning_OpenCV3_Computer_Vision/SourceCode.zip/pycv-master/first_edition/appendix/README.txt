Scripts are in the "cameo" folder.

The utils.py script is unchanged since Chapter 4.