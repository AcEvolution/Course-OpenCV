This directory contains material supporting chapter 10 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
Third Edition
by Robert Laganiere, Packt Publishing, 2016.

File:
	estimateF.cpp
correspond to Recipe:
Computing the Fundamental Matrix of an Image Pair
Files:
	matcher.h
	robustmatching.cpp
correspond to Recipe:
Matching Images using Random Sample Consensus
File:
	estimateH.cpp
correspond to Recipe:
Computing a homography between two images
Files:
	matchingTarget.cpp
        targetMatcher.h
correspond to Recipe:
Computing a homography between two images

You need the images:

church01.jpg
church02.jpg
church03.jpg
parliament1.jpg
parliament2.jpg
parliament3.jpg
cookbook1.bmp
objects.jpg


