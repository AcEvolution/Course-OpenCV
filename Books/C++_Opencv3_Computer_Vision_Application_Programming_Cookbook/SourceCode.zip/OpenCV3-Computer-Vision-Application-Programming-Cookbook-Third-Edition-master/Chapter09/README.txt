This directory contains material supporting chapter 9 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
Third Edition
by Robert Laganiere, Packt Publishing, 2016.

File:
	patches.cpp
correspond to Recipe:
Matching local templates

File:
	matcher.cpp
correspond to Recipe:
Describing and matching local intensity patterns

File:
	binaryDescriptors.cpp
correspond to Recipe:
Describing keypoints with binary features

You need the images:
church01.jpg
church02.jpg
church03.jpg
