This directory contains material supporting chapter 7 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
Third Edition
by Robert Laganiere, Packt Publishing, 2016.

Files:
	edgedetector.h
	linefinder.h
	contours.cpp
correspond to Recipes:
Detecting Image Contours with the Canny Operator
Detecting Lines in Images with the Hough Transform
Fitting a Line to a Set of Points

File:
	blobs.cpp
correspond to Recipes:
Extracting the Components� Contours
Computing Components� Shape Descriptors

You need the images:
group.jpg
binaryGroup.bmp
mser.bmp
road.jpg
chariot.jpg