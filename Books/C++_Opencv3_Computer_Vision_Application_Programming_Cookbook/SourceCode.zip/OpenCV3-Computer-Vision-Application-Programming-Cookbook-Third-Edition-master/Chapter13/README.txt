This directory contains material supporting chapter 13 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
Third Edition
by Robert Laganiere, Packt Publishing, 2016.

Files: 
	featuretracker.h
	traker.cpp
correspond to Recipe:
Tracing feature points in a video

File: 
	flow.cpp
Estimating the optical flow

Files: 
	visualtracker.h
	oTracker.cpp.h
Tracking an object in a video

You need the image sequences:
bike.avi
goose/*