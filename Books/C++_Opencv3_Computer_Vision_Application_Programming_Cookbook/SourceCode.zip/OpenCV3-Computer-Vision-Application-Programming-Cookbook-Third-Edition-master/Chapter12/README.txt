This directory contains material supporting chapter 12 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
Third Edition
by Robert Laganiere, Packt Publishing, 2016.

Files:
	videoprocessing.cpp
        videoprocessor.h
correspond to Recipes:
Reading Video Sequences
Processing the Video Frames
Writing Video Sequences

Files:
	BGFGSegmentor.h
	foreground.cpp
correspond to Recipe:
Extracting the Foreground Objects in Video

You need the image sequence:
bike.avi