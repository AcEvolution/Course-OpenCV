This directory contains material supporting chapter 8 of the cookbook:  
Computer Vision Programming using the OpenCV Library. 
Third Edition
by Robert Laganiere, Packt Publishing, 2016.

Files:
	harrisDetector.h
	interestPoints.cpp
correspond to Recipes:
Detecting Corners in images
Detecting features very fast
Detecting Scale-Invariant Features
Detecting fast features at multiple scales

You need the images:
church01.jpg
church02.jpg
church03.jpg
